define({
  "_themeLabel": "نُسُق لوحة المعلومات",
  "_layout_default": "تخطيط افتراضي",
  "_layout_right": "تخطيط صحيح"
});