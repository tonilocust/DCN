define({
  "_themeLabel": "Motyw panelu",
  "_layout_default": "Kompozycja domyślna",
  "_layout_right": "Kompozycja prawostronna"
});