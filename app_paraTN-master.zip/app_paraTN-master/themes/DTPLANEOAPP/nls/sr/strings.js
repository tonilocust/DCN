define({
  "_themeLabel": "Tema kontrolne table",
  "_layout_default": "Podrazumevani raspored",
  "_layout_right": "Desni raspored"
});