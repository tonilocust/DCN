define({
  "_themeLabel": "ערכת נושא של לוח מחוונים",
  "_layout_default": "פריסת ברירת מחדל",
  "_layout_right": "פריסה ימנית"
});