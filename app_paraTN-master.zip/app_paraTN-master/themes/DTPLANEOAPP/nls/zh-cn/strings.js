define({
  "_themeLabel": "仪表盘主题",
  "_layout_default": "默认布局",
  "_layout_right": "右侧布局"
});