define({
  "_themeLabel": "Tema do Dashboard",
  "_layout_default": "Layout predefinido",
  "_layout_right": "Layout direita"
});