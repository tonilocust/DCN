define({
  "_themeLabel": "ธีมแดชบอร์ด",
  "_layout_default": "เค้าโครงเริ่มต้น",
  "_layout_right": "รูปแบบที่เหมาะสม"
});